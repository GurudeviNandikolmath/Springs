package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import jakarta.servlet.http.HttpSession;

@org.springframework.stereotype.Controller
public class Controller 
{
	@Autowired
	StudentRepo repo;
	@RequestMapping("/std")
     String display()
     {
    	 return "details.jsp";
     }
	
	@RequestMapping("/saveStudent")
    String form(Student s)
    {
		repo.save(s);
   	 return "details.jsp";
    }
	
	@RequestMapping("/detailsById")
    String form1(HttpSession h, Integer sid)
    {
		Student s =repo.findById(sid).orElse(null);
		h.setAttribute("id", s.getSid());
		h.setAttribute("name", s.getSname());
		h.setAttribute("email", s.getEmail());
		h.setAttribute("phno", s.getPhno());
   	 return "view.jsp";
    }
	
	@RequestMapping("/deleteById")
    String delete(HttpSession h, Integer sid)
    {
		Student s =repo.findById(sid).orElse(null);
		if(s!=null)
		{
			h.setAttribute("message", "student with "+ sid +" got deleted");
			repo.deleteById(sid);
		}
		else {
		       h.setAttribute("message", "Invalid Student Id");	
		}
		
   	 return "delete.jsp";
    }
	
//	@RequestMapping("/findbyemail")
//	@ResponseBody
//	List<Student> findByEmail(String email)
//	{
//		return repo.findByEmail(email);
//	}

	@RequestMapping("/getbyphno")
	@ResponseBody
	List<Student> getByPhno()
	{
		return repo.getByPhno();
				
				
	}
	
	@RequestMapping("/getbyname")
	@ResponseBody
	List<Student> findByname(String sname)
	{
		return repo.findByname(sname);
				
				
	}
}
